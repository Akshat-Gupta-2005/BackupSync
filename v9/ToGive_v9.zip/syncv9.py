"""
FolderSync v9 — Two-way folder synchronization engine
Handles: CREATE, UPDATE, DELETE, CONFLICT resolution

v9 change: Added MTIME_TOLERANCE (default 60s) to ignore minor timestamp
differences caused by cloud mapped drives (WebDAV/SMB) that don't preserve
mtimes precisely on upload. Configurable via config.json or --mtime-tolerance.
"""

import os
import sys
import json
import shutil
import hashlib
import logging
import argparse
from pathlib import Path
from datetime import datetime

# ─── Logging Setup ────────────────────────────────────────────────────────────

LOG_WIDTH     = 72   # Total width of the log file columns
PREVIEW_WIDTH = 92   # Width for the terminal preview box

# ANSI colour codes — used in terminal preview only, never in the log file
C_RESET   = "\033[0m"
C_BOLD    = "\033[1m"
C_DIM     = "\033[2m"
C_GREEN   = "\033[32m"
C_YELLOW  = "\033[33m"
C_RED     = "\033[31m"
C_CYAN    = "\033[36m"
C_WHITE   = "\033[97m"
C_BG_RED  = "\033[41m"

# ─── Mtime Tolerance ──────────────────────────────────────────────────────────

# Cloud mapped drives (WebDAV, SMB, OneDrive, Google Drive, etc.) often shift
# a file's mtime by a few seconds to ~60s on upload without changing content.
# Any mtime difference smaller than this threshold is treated as "unchanged".
# Override via --mtime-tolerance <seconds> or "mtime_tolerance" in config.json.
DEFAULT_MTIME_TOLERANCE = 60  # seconds


class FileLogFormatter(logging.Formatter):
    """
    Structured formatter for the .log file.
    Produces clean, aligned, human-readable output with session blocks.

    Example output:
      ┌──────────────────────────────────────────────────────────────────────┐
      │  FOLDERSYNC SESSION  ·  2024-03-15 14:32:01                         │
      ├──────────────────────────────────────────────────────────────────────┤
      │  A  →  /home/user/docs                                               │
      │  B  →  /home/user/backup                                             │
      └──────────────────────────────────────────────────────────────────────┘
      14:32:01  CREATE    notes.txt                            A → B
      14:32:01  UPDATE    report.pdf                           B → A
      14:32:01  CONFLICT  budget.xlsx            [CONFLICT]    A wins
      14:32:01  DELETE    old_draft.txt                        from B
      14:32:01  INFO      State saved to sync_state.json
      14:32:01  ERROR     broken.zip: Permission denied
    """

    # Labels padded to fixed width so columns stay aligned
    LEVEL_LABELS = {
        "DEBUG":    "DEBUG   ",
        "INFO":     "INFO    ",
        "WARNING":  "WARNING ",
        "ERROR":    "ERROR   ",
        "CRITICAL": "CRITICAL",
    }

    def format(self, record: logging.LogRecord) -> str:
        time_str = self.formatTime(record, "%H:%M:%S")
        label = self.LEVEL_LABELS.get(record.levelname, record.levelname.ljust(8))
        msg = record.getMessage()
        return f"  {time_str}  {label}  {msg}"


class ConsoleLogFormatter(logging.Formatter):
    """Minimal formatter for stdout — timestamp + message only."""

    COLORS = {
        "DEBUG":    C_DIM,
        "INFO":     C_RESET,
        "WARNING":  C_YELLOW,
        "ERROR":    C_RED,
        "CRITICAL": "\033[1;31m",
    }

    def format(self, record: logging.LogRecord) -> str:
        time_str = self.formatTime(record, "%H:%M:%S")
        color = self.COLORS.get(record.levelname, "")
        msg = record.getMessage()
        return f"{color}{time_str}  {msg}{C_RESET}"


def _box_line(content: str = "", width: int = LOG_WIDTH, left: str = "│", right: str = "│") -> str:
    inner = width - 2  # subtract left + right border chars
    return f"{left}  {content:<{inner - 2}}{right}"


def write_session_header(log_file: str, folder_a: str, folder_b: str,
                         dry_run: bool = False, mtime_tolerance: int = DEFAULT_MTIME_TOLERANCE):
    """Write a formatted session-start block directly to the log file."""
    now = datetime.now().strftime("%Y-%m-%d  %H:%M:%S")
    mode = "  [DRY RUN — no files will be changed]" if dry_run else ""
    top    = "┌" + "─" * (LOG_WIDTH - 2) + "┐"
    sep    = "├" + "─" * (LOG_WIDTH - 2) + "┤"
    bottom = "└" + "─" * (LOG_WIDTH - 2) + "┘"

    lines = [
        "",
        top,
        _box_line(f"FOLDERSYNC SESSION  ·  {now}{mode}"),
        sep,
        _box_line(f"SOURCE  →  {folder_a}"),
        _box_line(f"DEST    →  {folder_b}"),
        _box_line(f"MTIME TOLERANCE  →  {mtime_tolerance}s"),
        bottom,
    ]
    with open(log_file, "a", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def write_session_footer(log_file: str, result: "SyncResult", elapsed: float):
    """Write a formatted session-end summary block to the log file."""
    sep    = "  " + "─" * (LOG_WIDTH - 2)
    lines = [
        sep,
        f"  {'RESULT':<12}  Created={len(result.created)}  Updated={len(result.updated)}  "
        f"Deleted={len(result.deleted)}  Conflicts={len(result.conflicts)}  "
        f"Skipped={len(result.skipped)}  Errors={len(result.errors)}",
        f"  {'ELAPSED':<12}  {elapsed:.3f}s",
        sep,
        "",
    ]
    with open(log_file, "a", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def setup_logging(log_file: str = "sync.log", verbose: bool = False):
    level = logging.DEBUG if verbose else logging.INFO

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(ConsoleLogFormatter())
    console_handler.setLevel(level)

    handlers: list[logging.Handler] = [console_handler]

    if log_file:
        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setFormatter(FileLogFormatter())
        file_handler.setLevel(logging.DEBUG)  # always capture everything in file
        handlers.append(file_handler)

    root = logging.getLogger()
    root.setLevel(logging.DEBUG)
    for h in handlers:
        root.addHandler(h)


log = logging.getLogger(__name__)

# ─── State Management ─────────────────────────────────────────────────────────

STATE_FILE = "sync_state.json"

def _state_file_for(name: str) -> str:
    """Return a unique state filename for a named pair, e.g. sync_state_Projects.json"""
    safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in name)
    return f"sync_state_{safe}.json"

def load_state(state_file: str = None) -> dict:
    """Load the last sync snapshot from disk."""
    path = state_file or STATE_FILE
    if not os.path.exists(path):
        return {"last_sync": None, "files_a": {}, "files_b": {}}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def save_state(folder_a: str, folder_b: str, state_file: str = None):
    """Snapshot current state of both folders after a successful sync."""
    path = state_file or STATE_FILE
    state = {
        "last_sync": datetime.now().isoformat(),
        "files_a": snapshot_folder(folder_a),
        "files_b": snapshot_folder(folder_b),
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2)
    log.debug(f"State saved to {path}")

def snapshot_folder(folder: str) -> dict:
    """Return {relative_path: mtime} for every file in folder."""
    snap = {}
    base = Path(folder)
    for p in base.rglob("*"):
        if p.is_file():
            rel = str(p.relative_to(base))
            snap[rel] = p.stat().st_mtime
    return snap

# ─── File Utilities ───────────────────────────────────────────────────────────

def get_mtime(path: str) -> float:
    return os.path.getmtime(path)

def file_hash(path: str) -> str:
    """MD5 hash of a file — used to skip identical files even if mtimes differ."""
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()

def safe_copy(src: str, dst: str):
    """Copy src → dst, creating intermediate directories as needed."""
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copy2(src, dst)  # copy2 preserves timestamps

def safe_delete(path: str):
    """Delete a file if it exists."""
    if os.path.exists(path):
        os.remove(path)
        # Clean up empty parent directories
        parent = os.path.dirname(path)
        try:
            if os.path.isdir(parent) and not os.listdir(parent):
                os.removedirs(parent)
        except OSError:
            pass

# ─── Change Detection ─────────────────────────────────────────────────────────

def _mtime_changed(curr: float, prev: float, tolerance: int) -> bool:
    """
    Return True only if the mtime difference exceeds the tolerance threshold.
    This prevents cloud drives that silently shift mtimes on upload (typically
    30–60 s) from being mistaken for genuine user edits.
    """
    return abs(curr - prev) > tolerance

# ─── Core Sync Logic ──────────────────────────────────────────────────────────

class SyncResult:
    def __init__(self):
        self.created = []
        self.updated = []
        self.deleted = []
        self.conflicts = []
        self.skipped = []
        self.errors = []

    def summary(self):
        return (
            f"\n{'─'*50}\n"
            f"  ✅  Created   : {len(self.created)}\n"
            f"  🔄  Updated   : {len(self.updated)}\n"
            f"  🗑️   Deleted   : {len(self.deleted)}\n"
            f"  ⚠️   Conflicts : {len(self.conflicts)}\n"
            f"  ⏭️   Skipped   : {len(self.skipped)}\n"
            f"  ❌  Errors    : {len(self.errors)}\n"
            f"{'─'*50}"
        )


def _log_action(action: str, filename: str, detail: str = ""):
    """
    Emit a fixed-width action line so all columns stay aligned in the log.

    Output format (inside the formatter's timestamp + level prefix):
      CREATE    notes.txt                                    A → B
      UPDATE    report.pdf                                   B → A
      CONFLICT  budget.xlsx                     [CONFLICT]   A wins
      DELETE    old_draft.txt                               from B
      SKIP      unchanged.png                              identical
    """
    col_action = f"{action:<10}"   # 10 chars: CREATE, UPDATE, DELETE, CONFLICT, SKIP
    col_file   = f"{filename:<44}" # 44 chars for filename (truncated if needed)
    col_detail = detail
    msg = f"{col_action}{col_file}{col_detail}"
    if action == "CONFLICT":
        log.warning(msg)
    elif action in ("ERROR",):
        log.error(msg)
    elif action == "SKIP":
        log.debug(msg)
    else:
        log.info(msg)


# ─── Pre-flight: planned actions ─────────────────────────────────────────────

from dataclasses import dataclass, field

@dataclass
class PlannedAction:
    """Represents one file operation decided during the scan pass."""
    action:  str         # CREATE | UPDATE | DELETE | CONFLICT | SKIP | ERROR
    rel:     str         # relative file path
    detail:  str = ""    # human-readable detail string
    winner:  str = ""    # "A" or "B" — for copy ops
    loser:   str = ""    # the side that gets overwritten/deleted


def scan_folders(
    folder_a: str,
    folder_b: str,
    state_file: str = None,
    mtime_tolerance: int = DEFAULT_MTIME_TOLERANCE,
) -> list[PlannedAction]:
    """
    Analyse both folders and return the full list of planned actions.
    Does NOT touch any files — purely reads mtimes and hashes.
    Same logic as sync_folders but returns PlannedAction objects instead
    of executing anything.

    mtime_tolerance: mtime differences within this many seconds are ignored.
    Prevents cloud drives from triggering spurious updates on files whose
    content hasn't changed but whose timestamp was shifted on upload.
    """
    path_a = Path(folder_a)
    path_b = Path(folder_b)

    if not path_a.exists():
        log.error(f"Source folder does not exist: {folder_a}")
        sys.exit(1)
    if not path_b.exists():
        log.error(f"Destination folder does not exist: {folder_b}")
        sys.exit(1)

    state    = load_state(state_file)
    prev_a   = state.get("files_a", {})
    prev_b   = state.get("files_b", {})
    first_run = state["last_sync"] is None

    curr_a    = snapshot_folder(folder_a)
    curr_b    = snapshot_folder(folder_b)
    all_files = set(curr_a.keys()) | set(curr_b.keys()) | set(prev_a.keys()) | set(prev_b.keys())

    actions: list[PlannedAction] = []

    for rel in sorted(all_files):
        file_a = str(path_a / rel)
        file_b = str(path_b / rel)

        in_a     = rel in curr_a
        in_b     = rel in curr_b
        was_in_a = rel in prev_a
        was_in_b = rel in prev_b

        display = rel if len(rel) <= 43 else "…" + rel[-42:]

        try:
            if in_a and in_b:
                mtime_a = curr_a[rel]
                mtime_b = curr_b[rel]

                if file_hash(file_a) == file_hash(file_b):
                    actions.append(PlannedAction("SKIP", display, "identical"))
                    continue

                if not first_run:
                    changed_a = was_in_a and _mtime_changed(mtime_a, prev_a.get(rel, mtime_a), mtime_tolerance)
                    changed_b = was_in_b and _mtime_changed(mtime_b, prev_b.get(rel, mtime_b), mtime_tolerance)
                else:
                    changed_a = changed_b = False

                if changed_a and changed_b:
                    winner = "A" if mtime_a >= mtime_b else "B"
                    loser  = "B" if winner == "A" else "A"
                    actions.append(PlannedAction("CONFLICT", display,
                                                 f"[CONFLICT]  {winner} wins  →  overwriting {loser}",
                                                 winner=winner, loser=loser))
                else:
                    if mtime_a >= mtime_b:
                        actions.append(PlannedAction("UPDATE", display, "A → B", winner="A", loser="B"))
                    else:
                        actions.append(PlannedAction("UPDATE", display, "B → A", winner="B", loser="A"))

            elif in_a and not in_b:
                if not first_run and was_in_b and not in_b:
                    actions.append(PlannedAction("DELETE", display,
                                                 "removed from B  →  purging from A", loser="A"))
                else:
                    actions.append(PlannedAction("CREATE", display, "A → B", winner="A", loser="B"))

            elif in_b and not in_a:
                if not first_run and was_in_a and not in_a:
                    actions.append(PlannedAction("DELETE", display,
                                                 "removed from A  →  purging from B", loser="B"))
                else:
                    actions.append(PlannedAction("CREATE", display, "B → A", winner="B", loser="A"))

            else:
                actions.append(PlannedAction("SKIP", display, "gone from both"))

        except Exception as e:
            actions.append(PlannedAction("ERROR", display, str(e)))

    return actions


# ─── Terminal preview ─────────────────────────────────────────────────────────

# Action metadata: (colour, bullet, label shown in preview)
ACTION_META = {
    "CREATE":   (C_GREEN,  "  +  ", "CREATE  "),
    "UPDATE":   (C_CYAN,   "  ↑  ", "UPDATE  "),
    "DELETE":   (C_RED,    "  ✕  ", "DELETE  "),
    "CONFLICT": (C_YELLOW, "  ⚠  ", "CONFLICT"),
    "SKIP":     (C_DIM,    "  ·  ", "SKIP    "),
    "ERROR":    (C_BG_RED, "  !  ", "ERROR   "),
}


_ANSI_RE = __import__("re").compile(r"\033\[[0-9;]*m")

def _visible_len(s: str) -> int:
    """Return the printable length of a string, ignoring ANSI escape codes."""
    return len(_ANSI_RE.sub("", s))

def _pv_line(content: str = "", width: int = PREVIEW_WIDTH,
             left: str = "│", right: str = "│", color: str = "") -> str:
    inner   = width - 6  # │ + 2-space pad on each side = 6 chars total border
    full    = color + content + C_RESET
    padding = max(0, inner - _visible_len(color + content))
    return f"{left}  {full}{' ' * padding}  {right}"


def print_preview(pair_name: str, folder_a: str, folder_b: str,
                  actions: list[PlannedAction], mtime_tolerance: int = DEFAULT_MTIME_TOLERANCE):
    """
    Print the full pre-flight preview to the terminal.
    Shows a header with pair name + folder paths, then every planned action
    grouped by type (CONFLICT first, then DELETE, CREATE, UPDATE, ERROR, SKIP),
    then a summary count table.
    """
    W      = PREVIEW_WIDTH
    top    = "┌" + "─" * (W - 2) + "┐"
    sep    = "├" + "─" * (W - 2) + "┤"
    bottom = "└" + "─" * (W - 2) + "┘"
    thin   = "├" + "╌" * (W - 2) + "┤"

    now = datetime.now().strftime("%Y-%m-%d  %H:%M:%S")

    print()
    print(f"{C_BOLD}{C_WHITE}{top}{C_RESET}")
    print(_pv_line(f"  FOLDERSYNC  ·  PRE-FLIGHT PREVIEW  ·  {now}  ·  {pair_name}",
                   W, color=C_BOLD + C_WHITE))
    print(f"{C_BOLD}{C_WHITE}{sep}{C_RESET}")

    for label, path in (("SOURCE", folder_a), ("DEST", folder_b)):
        truncated = path if len(path) <= W - 20 else "…" + path[-(W - 21):]
        print(_pv_line(f"{C_CYAN}{label:<10}{C_RESET}{C_DIM}→{C_RESET}  {truncated}", W))

    print(_pv_line(f"{C_DIM}MTIME TOLERANCE  →  {mtime_tolerance}s{C_RESET}", W))

    # ── Bucket actions by type ────────────────────────────────────────────────
    buckets: dict[str, list[PlannedAction]] = {
        "CREATE": [], "UPDATE": [], "DELETE": [],
        "CONFLICT": [], "SKIP": [], "ERROR": [],
    }
    for a in actions:
        buckets.get(a.action, buckets["ERROR"]).append(a)

    shown_types = [t for t in ("CONFLICT", "DELETE", "CREATE", "UPDATE", "ERROR", "SKIP")
                   if buckets[t]]

    for action_type in shown_types:
        group  = buckets[action_type]
        color, bullet, label = ACTION_META[action_type]

        print(f"{C_BOLD}{C_WHITE}{sep}{C_RESET}")
        print(_pv_line(f"{color}{C_BOLD}{label}  ×{len(group)}{C_RESET}", W, color=""))
        print(f"{C_BOLD}{C_WHITE}{thin}{C_RESET}")

        for a in group:
            fname_col  = 42
            fname      = a.rel if len(a.rel) <= fname_col else "…" + a.rel[-(fname_col - 1):]
            fname_pad  = f"{fname:<{fname_col}}"
            detail_col = W - 4 - fname_col - 6
            detail     = a.detail if len(a.detail) <= detail_col else a.detail[:detail_col - 1] + "…"
            row = f"{color}{bullet}{C_RESET}{fname_pad}  {C_DIM}{detail}{C_RESET}"
            print(_pv_line(row, W, color=""))

    # ── Summary count table ───────────────────────────────────────────────────
    print(f"{C_BOLD}{C_WHITE}{sep}{C_RESET}")

    counts       = {t: len(buckets[t]) for t in buckets}
    total_changes = sum(counts[t] for t in ("CREATE", "UPDATE", "DELETE", "CONFLICT"))
    col_w = (W - 6) // 6

    headers = (f"{'CREATE':<{col_w}}{'UPDATE':<{col_w}}{'DELETE':<{col_w}}"
               f"{'CONFLICT':<{col_w}}{'SKIP':<{col_w}}{'ERRORS':<{col_w}}")
    values  = (
        f"{C_GREEN}{counts['CREATE']:<{col_w}}{C_RESET}"
        f"{C_CYAN}{counts['UPDATE']:<{col_w}}{C_RESET}"
        f"{C_RED}{counts['DELETE']:<{col_w}}{C_RESET}"
        f"{C_YELLOW}{counts['CONFLICT']:<{col_w}}{C_RESET}"
        f"{C_DIM}{counts['SKIP']:<{col_w}}{C_RESET}"
        f"{C_RED if counts['ERROR'] else C_DIM}{counts['ERROR']:<{col_w}}{C_RESET}"
    )
    print(_pv_line(f"{C_DIM}{headers}{C_RESET}", W, color=""))
    print(_pv_line(values, W, color=""))
    print(f"{C_BOLD}{C_WHITE}{thin}{C_RESET}")

    if total_changes == 0:
        print(_pv_line(f"{C_GREEN}{C_BOLD}  All folders already in sync. No changes needed.{C_RESET}", W, color=""))
    else:
        print(_pv_line(
            f"{C_BOLD}  {total_changes} operation(s) planned  ·  "
            f"{counts['CONFLICT']} conflict(s)  ·  {counts['ERROR']} error(s){C_RESET}", W, color=""))

    print(f"{C_BOLD}{C_WHITE}{bottom}{C_RESET}")
    print()


# ─── Confirmation prompt ──────────────────────────────────────────────────────

def ask_confirmation(actions: list[PlannedAction]) -> bool:
    """
    Print the confirmation prompt and wait for user input.
    Returns True if the user confirmed, False if aborted.
    """
    changes = [a for a in actions if a.action != "SKIP"]
    errors  = [a for a in actions if a.action == "ERROR"]

    if not changes and not errors:
        print(f"  {C_DIM}Nothing to sync. Skipping.{C_RESET}\n")
        return False

    if errors:
        print(f"  {C_YELLOW}⚠  {len(errors)} error(s) detected during scan. "
              f"They will be skipped during sync.{C_RESET}")

    print(f"  {C_BOLD}Proceed with sync?{C_RESET}  "
          f"{C_GREEN}[Y]{C_RESET} Yes   "
          f"{C_RED}[N]{C_RESET} No / Abort"
          f"  {C_DIM}(default: N){C_RESET}")
    print()

    try:
        answer = input("  → ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print(f"\n  {C_RED}Aborted.{C_RESET}\n")
        return False

    if answer in ("y", "yes"):
        print()
        return True

    print(f"\n  {C_RED}Sync aborted. No files were changed.{C_RESET}\n")
    return False


# ─── Core Sync Engine ─────────────────────────────────────────────────────────

def sync_folders(
    folder_a: str,
    folder_b: str,
    dry_run: bool = False,
    log_file: str = "sync.log",
    state_file: str = None,
    mtime_tolerance: int = DEFAULT_MTIME_TOLERANCE,
) -> "SyncResult":
    """
    Main sync engine. Applies all 4 rules:
      CREATE   — file in A not in B (or vice versa) → copy to other
      UPDATE   — file in both, one is newer → overwrite older
      DELETE   — file deleted from one since last sync → delete from other
      CONFLICT — file modified in both since last sync → newer wins

    mtime_tolerance: mtime differences within this many seconds are ignored.
    Cloud drives commonly shift mtimes by 30–60 s on upload without modifying
    content. Without tolerance, every synced file would re-trigger an UPDATE
    on the next run.
    """
    import time
    start_time = time.monotonic()

    result = SyncResult()
    state = load_state(state_file)
    prev_a = state.get("files_a", {})
    prev_b = state.get("files_b", {})
    first_run = state["last_sync"] is None

    path_a = Path(folder_a)
    path_b = Path(folder_b)

    if not path_a.exists():
        log.error(f"Folder A does not exist: {folder_a}")
        sys.exit(1)
    if not path_b.exists():
        log.error(f"Folder B does not exist: {folder_b}")
        sys.exit(1)

    # Write session header block to log file
    if log_file:
        write_session_header(log_file, folder_a, folder_b, dry_run, mtime_tolerance)

    log.info(f"{'Files evaluated':<44}scanning...")
    log.debug(f"{'Mtime tolerance':<44}{mtime_tolerance}s")

    # Current snapshots
    curr_a = snapshot_folder(folder_a)
    curr_b = snapshot_folder(folder_b)
    all_files = set(curr_a.keys()) | set(curr_b.keys()) | set(prev_a.keys()) | set(prev_b.keys())

    log.info(f"{'Files evaluated':<44}{len(all_files)} files  |  first_run={first_run}")

    for rel in sorted(all_files):
        file_a = str(path_a / rel)
        file_b = str(path_b / rel)

        in_a = rel in curr_a
        in_b = rel in curr_b
        was_in_a = rel in prev_a
        was_in_b = rel in prev_b

        # Truncate long filenames in log so columns don't break
        display = rel if len(rel) <= 43 else "…" + rel[-(42):]

        try:
            # ── CASE 1: EXISTS IN BOTH ──────────────────────────────────────
            if in_a and in_b:
                mtime_a = curr_a[rel]
                mtime_b = curr_b[rel]

                if file_hash(file_a) == file_hash(file_b):
                    _log_action("SKIP", display, "identical")
                    result.skipped.append(rel)
                    continue

                if not first_run:
                    changed_a = was_in_a and _mtime_changed(mtime_a, prev_a.get(rel, mtime_a), mtime_tolerance)
                    changed_b = was_in_b and _mtime_changed(mtime_b, prev_b.get(rel, mtime_b), mtime_tolerance)
                else:
                    changed_a = changed_b = False

                if changed_a and changed_b:
                    winner = "A" if mtime_a >= mtime_b else "B"
                    _log_action("CONFLICT", display, f"[CONFLICT]  {winner} wins")
                    if not dry_run:
                        safe_copy(file_a, file_b) if winner == "A" else safe_copy(file_b, file_a)
                    result.conflicts.append(f"{rel} (winner: {winner})")
                else:
                    if mtime_a >= mtime_b:
                        _log_action("UPDATE", display, "A → B")
                        if not dry_run:
                            safe_copy(file_a, file_b)
                    else:
                        _log_action("UPDATE", display, "B → A")
                        if not dry_run:
                            safe_copy(file_b, file_a)
                    result.updated.append(rel)

            # ── CASE 2: ONLY IN A ───────────────────────────────────────────
            elif in_a and not in_b:
                if not first_run and was_in_b and not in_b:
                    _log_action("DELETE", display, "removed from B  →  purged from A")
                    if not dry_run:
                        safe_delete(file_a)
                    result.deleted.append(rel)
                else:
                    _log_action("CREATE", display, "A → B")
                    if not dry_run:
                        safe_copy(file_a, file_b)
                    result.created.append(rel)

            # ── CASE 3: ONLY IN B ───────────────────────────────────────────
            elif in_b and not in_a:
                if not first_run and was_in_a and not in_a:
                    _log_action("DELETE", display, "removed from A  →  purged from B")
                    if not dry_run:
                        safe_delete(file_b)
                    result.deleted.append(rel)
                else:
                    _log_action("CREATE", display, "B → A")
                    if not dry_run:
                        safe_copy(file_b, file_a)
                    result.created.append(rel)

            # ── CASE 4: IN NEITHER (was deleted from both) ──────────────────
            else:
                _log_action("SKIP", display, "gone from both")

        except Exception as e:
            _log_action("ERROR", display, str(e))
            result.errors.append(f"{rel}: {e}")

    if not dry_run:
        save_state(folder_a, folder_b, state_file)

    elapsed = time.monotonic() - start_time
    if log_file:
        write_session_footer(log_file, result, elapsed)

    return result


# ─── CLI Entry Point ──────────────────────────────────────────────────────────

def load_config(config_path: str) -> tuple[list[dict], int]:
    """
    Load config.json. Supports two formats:

    NEW — multi-pair:
      {
        "mtime_tolerance": 60,          ← optional, global default (seconds)
        "pairs": [
          { "name": "Projects", "source": "D:/A", "destination": "D:/B" },
          { "name": "Docs",     "source": "C:/Work", "destination": "E:/Backup",
            "mtime_tolerance": 30 }     ← optional, per-pair override
        ]
      }

    LEGACY — single pair (v5 and earlier):
      { "folder_a": "D:/A", "folder_b": "D:/B" }

    'source' and 'destination' are labels only — sync is always bidirectional.
    'name' is optional but recommended; used for state file naming and log headers.

    Returns (pairs, global_mtime_tolerance).
    """
    with open(config_path, "r") as f:
        cfg = json.load(f)

    global_tolerance = int(cfg.get("mtime_tolerance", DEFAULT_MTIME_TOLERANCE))

    if "pairs" in cfg:
        pairs = cfg["pairs"]
        for i, p in enumerate(pairs):
            if "source" not in p or "destination" not in p:
                raise ValueError(f"Pair #{i + 1} in config is missing 'source' or 'destination'.")
            if "name" not in p:
                p["name"] = f"pair_{i + 1}"
        return pairs, global_tolerance

    # Legacy single-pair format
    if "folder_a" in cfg and "folder_b" in cfg:
        return [{"name": "default", "source": cfg["folder_a"], "destination": cfg["folder_b"]}], global_tolerance

    raise ValueError(
        "config.json must contain a 'pairs' array or legacy 'folder_a'/'folder_b' keys."
    )


def main():
    parser = argparse.ArgumentParser(
        description=(
            "FolderSync v9 — Two-way folder sync with CREATE/UPDATE/DELETE/CONFLICT handling\n"
            "Scans folders, shows a pre-flight preview of all planned actions,\n"
            "then asks for confirmation before touching any file.\n\n"
            "Use --yes to skip confirmation (for scheduled/automated runs).\n\n"
            "v9: Added --mtime-tolerance to ignore cloud drive timestamp drift.\n"
            "    Cloud mapped drives (WebDAV, OneDrive, etc.) can shift mtimes\n"
            "    by 30–60 s on upload. Set tolerance >= that drift to avoid\n"
            "    spurious re-updates on every sync run."
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    parser.add_argument("folder_a", nargs="?", help="Path to Folder A (single-pair CLI mode)")
    parser.add_argument("folder_b", nargs="?", help="Path to Folder B (single-pair CLI mode)")
    parser.add_argument("--yes",      "-y",  action="store_true", help="Skip confirmation prompt (auto-confirm)")
    parser.add_argument("--dry-run",         action="store_true", help="Preview only — never execute")
    parser.add_argument("--verbose",  "-v",  action="store_true", help="Show debug output")
    parser.add_argument("--log",             default="sync.log",  help="Log file path (default: sync.log)")
    parser.add_argument("--config",          default="config.json", help="Config file path (default: config.json)")
    parser.add_argument(
        "--mtime-tolerance",
        type=int,
        default=None,
        metavar="SECONDS",
        help=(
            f"Ignore mtime differences smaller than this many seconds (default: {DEFAULT_MTIME_TOLERANCE}).\n"
            "Useful for cloud mapped drives that shift timestamps on upload.\n"
            "Set to 0 to disable tolerance and use exact mtime comparison."
        ),
    )
    parser.add_argument(
        "--reset-state",
        action="store_true",
        help="Delete state file(s) and treat next run as first sync",
    )
    args = parser.parse_args()

    setup_logging(args.log, args.verbose)

    # ── Resolve pairs ──────────────────────────────────────────────────────────

    config_tolerance = DEFAULT_MTIME_TOLERANCE

    if args.folder_a and args.folder_b:
        pairs = [{"name": "default", "source": args.folder_a, "destination": args.folder_b}]
    elif os.path.exists(args.config):
        try:
            pairs, config_tolerance = load_config(args.config)
        except (ValueError, KeyError) as e:
            log.error(f"Config error: {e}")
            sys.exit(1)
    else:
        log.error("Please provide folder_a and folder_b as arguments or set up config.json")
        parser.print_help()
        sys.exit(1)

    # CLI flag overrides config value
    mtime_tolerance = args.mtime_tolerance if args.mtime_tolerance is not None else config_tolerance

    # ── Reset state ────────────────────────────────────────────────────────────

    if args.reset_state:
        for pair in pairs:
            sf = _state_file_for(pair["name"])
            if os.path.exists(sf):
                os.remove(sf)
                log.info(f"State reset for pair '{pair['name']}' ({sf})")
        log.info("All state files cleared. Next sync will be treated as first run.")

    # ── Per-pair: scan → preview → confirm → execute ───────────────────────────

    all_results = []
    any_errors  = False

    for pair in pairs:
        name = pair["name"]
        src  = pair["source"]
        dst  = pair["destination"]
        sf   = _state_file_for(name)

        # Per-pair tolerance overrides global if present
        pair_tolerance = int(pair.get("mtime_tolerance", mtime_tolerance))

        if len(pairs) > 1:
            log.info(f"{'─'*50}")
            log.info(f"Pair: {name}  |  {src}  ↔  {dst}")

        # PASS 1: Scan
        print(f"\n  {C_DIM}Scanning '{name}'...{C_RESET}")
        actions = scan_folders(src, dst, state_file=sf, mtime_tolerance=pair_tolerance)

        # PASS 2: Preview
        print_preview(name, src, dst, actions, mtime_tolerance=pair_tolerance)

        # Dry-run exits after preview
        if args.dry_run:
            print(f"  {C_DIM}Dry-run mode — no files changed.{C_RESET}\n")
            continue

        # PASS 3: Confirm
        if not args.yes:
            confirmed = ask_confirmation(actions)
            if not confirmed:
                continue
        else:
            changes = [a for a in actions if a.action != "SKIP"]
            if not changes:
                print(f"  {C_DIM}Nothing to sync for '{name}'. Skipping.{C_RESET}\n")
                continue
            print(f"  {C_DIM}--yes flag set. Proceeding automatically.{C_RESET}\n")

        # PASS 4: Execute
        try:
            result = sync_folders(
                src, dst,
                dry_run=False,
                log_file=args.log,
                state_file=sf,
                mtime_tolerance=pair_tolerance,
            )
            all_results.append((name, result))
            if result.errors:
                any_errors = True
        except Exception as e:
            log.error(f"Pair '{name}' failed with unexpected error: {e}")
            any_errors = True

    # ── Print final summary ────────────────────────────────────────────────────

    if not all_results:
        return  # dry-run or all pairs skipped/aborted

    if len(all_results) == 1:
        print(all_results[0][1].summary())
    else:
        print(f"\n{'═'*50}")
        print(f"  MULTI-PAIR SUMMARY  ({len(all_results)} pairs)")
        print(f"{'═'*50}")
        for name, result in all_results:
            print(
                f"  {name:<20}  "
                f"✅ {len(result.created):>3} created  "
                f"🔄 {len(result.updated):>3} updated  "
                f"🗑️  {len(result.deleted):>3} deleted  "
                f"⚠️  {len(result.conflicts):>3} conflicts  "
                f"❌ {len(result.errors):>3} errors"
            )
        print(f"{'═'*50}\n")

    if any_errors:
        sys.exit(1)


if __name__ == "__main__":
    main()
